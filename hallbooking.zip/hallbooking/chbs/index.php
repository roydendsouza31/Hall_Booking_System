<?php include('includes/header.php'); ?>


<div class="jumbotron text-center">
	<h2>Welcome to Hall Management System.</h2>
	<p>All in one place.</p>
</div>
		
<?php include ('includes/footer.php');?>
		