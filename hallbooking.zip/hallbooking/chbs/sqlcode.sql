CREATE DATABASE hallbooking;
use hallbooking;

-- Table structure for table booking
--

CREATE TABLE booking (
  booking_id int(10) NOT NULL,
  client_id int(10) NOT NULL,
  hall_id int(10) NOT NULL,
  slot varchar(10) NOT NULL,
  date date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Table structure for table client
--

CREATE TABLE client (
  client_id int(10) NOT NULL,
  name varchar(200) NOT NULL,
  phone varchar(15) NOT NULL,
  address varchar(200) NOT NULL,
  email varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Table structure for table hall
--

CREATE TABLE hall (
  hall_id int(10) NOT NULL,
  name varchar(200) NOT NULL,
  phone varchar(15) NOT NULL,
  address varchar(200) NOT NULL,
  rent int(10) NOT NULL,
  size varchar(10) NOT NULL,
  manager_id int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Table structure for table manager
--

CREATE TABLE manager (
  manager_id int(10) NOT NULL,
  name varchar(200) NOT NULL,
  phone varchar(15) NOT NULL,
  email varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table users
--

CREATE TABLE users (
  username varchar(50) NOT NULL,
  password text NOT NULL,
  type varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- Indexes for dumped tables
--

--
-- Indexes for table booking
--
ALTER TABLE booking
  ADD PRIMARY KEY (booking_id),
  ADD KEY client_id (client_id),
  ADD KEY hall_id (hall_id);

--
-- Indexes for table client
--
ALTER TABLE client
  ADD PRIMARY KEY (client_id);

--
-- Indexes for table hall
--
ALTER TABLE hall
  ADD PRIMARY KEY (hall_id),
  ADD KEY manager_id (manager_id);

--
-- Indexes for table manager
--
ALTER TABLE manager
  ADD PRIMARY KEY (manager_id);

--
-- Indexes for table users
--
ALTER TABLE users
  ADD PRIMARY KEY (username);

--
-- AUTO_INCREMENT for table booking
--
ALTER TABLE booking
  MODIFY booking_id int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table client
--
ALTER TABLE client
  MODIFY client_id int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table hall
--
ALTER TABLE hall
  MODIFY hall_id int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table manager
--
ALTER TABLE manager
  MODIFY manager_id int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for table booking
--
ALTER TABLE booking
  ADD CONSTRAINT booking_ibfk_1 FOREIGN KEY (client_id) REFERENCES client (client_id) ON UPDATE CASCADE,
  ADD CONSTRAINT booking_ibfk_2 FOREIGN KEY (hall_id) REFERENCES hall (hall_id) ON UPDATE CASCADE;

--
-- Constraints for table hall
--
ALTER TABLE hall
  ADD CONSTRAINT hall_ibfk_1 FOREIGN KEY (manager_id) REFERENCES manager (manager_id) ON UPDATE CASCADE;
COMMIT;