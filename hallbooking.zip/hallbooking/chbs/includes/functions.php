<?php
global $dblink;
$db_user = "root";
$db_pass = "";
$db_name = "hallbooking";
$dblink = mysqli_connect('localhost',$db_user,$db_pass,$db_name);

	if(!$dblink){
		echo 'Connection Error';
	}
	function redirect_to($new_location) {
	  header("Location: " . $new_location);
	  exit;
	}

		function nav(){?>
		
			 <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
		      <a class="navbar-brand" href="#">Hall Management System</a>
		      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
		        <span class="navbar-toggler-icon"></span>
		      </button>

		      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
		        <ul class="navbar-nav mr-auto">
		          <li class="nav-item active">
		            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
		          </li>
		          
		          
		          <li class="nav-item dropdown">
		            <a class="nav-link dropdown-toggle" href="view_client.php" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Client</a>
		            <div class="dropdown-menu" aria-labelledby="dropdown01">
		              <a class="dropdown-item" href="add_client.php"><i class="fa fa-plus"></i> Add</a>
		              <a class="dropdown-item" href="view_client.php"><i class="fa fa-eye"></i> View</a>
		              <a class="dropdown-item" href="edit_client.php"><i class="fa fa-edit"></i> Edit</a>
		            </div>
		          </li>
		          <li class="nav-item dropdown">
		            <a class="nav-link dropdown-toggle" href="view_manager.php" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Halls</a>
		            <div class="dropdown-menu" aria-labelledby="dropdown01">
		              <a class="dropdown-item" href="add_hall.php"><i class="fa fa-plus"></i> Add</a>
		              <a class="dropdown-item" href="view_hall.php"><i class="fa fa-eye"></i> View</a>
		              <a class="dropdown-item" href="edit_hall.php"><i class="fa fa-edit"></i> Edit</a>
		              
		            </div>
		            <li class="nav-item dropdown">
		            <a class="nav-link dropdown-toggle" href="view_hall.php" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Manager</a>
		            <div class="dropdown-menu" aria-labelledby="dropdown01">
		              <a class="dropdown-item" href="add_manager.php"><i class="fa fa-plus"></i> Add</a>
		              <a class="dropdown-item" href="view_manager.php"><i class="fa fa-eye"></i> View</a>
		              <a class="dropdown-item" href="edit_manager.php"><i class="fa fa-edit"></i> Edit</a>
		              
		            </div>
		          </li>
		          <li class="nav-item dropdown">
		            <a class="nav-link dropdown-toggle" href="view_booking.php" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Booking</a>
		            <div class="dropdown-menu" aria-labelledby="dropdown01">
		              <a class="dropdown-item" href="add_booking.php"><i class="fa fa-plus"></i> Add</a>
		              <a class="dropdown-item" href="view_booking.php"><i class="fa fa-eye"></i> View</a>
		              <a class="dropdown-item" href="edit_booking.php"><i class="fa fa-edit"></i> Edit</a>
		              
		            </div>
		          </li>
		        </ul>
		      </div>
		    </nav>
		<?php 
		}

		function successMsg($msg){
			echo '<div class="alert alert-success">'.$msg.'</div>';
		}
		function dangerMsg($msg){
			echo '<div class="alert alert-danger">'.$msg.'</div>';
		}
		function alertMsg($msg){
			echo '<div class="alert alert-warning">'.$msg.'</div>';
		}

		function getManager($id){
			global $dblink;
			$query = "SELECT * FROM manager where manager_id = '{$id}'";
			$manager = mysqli_query($dblink,$query);
			$r = mysqli_fetch_assoc($manager);
			return $r;
		}
		function getClient($id){
			global $dblink;
			$query = "SELECT * FROM client where client_id = '{$id}'";
			$client = mysqli_query($dblink,$query);
			$r = mysqli_fetch_assoc($client);
			return $r;
		}
		function getHall($id){
			global $dblink;
			$query = "SELECT * FROM hall where hall_id = '{$id}'";
			$hall = mysqli_query($dblink,$query);
			$r = mysqli_fetch_assoc($hall);
			return $r;
		}

?>