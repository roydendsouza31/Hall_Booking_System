</main>
<br>
<br>
<br>
<br>
<br>
 <footer class="footer">
      <div class="container">
        <span class="text-muted">&copy; Hall Owners Association.</span>
      </div>
  </footer>
	
	<script type="text/javascript" src="includes/jquery.js"></script>
	<script type="text/javascript" src="includes/bootstrap.min.js"></script>
	<script type="text/javascript" src="includes/script.js"></script>
</body>
</html>
